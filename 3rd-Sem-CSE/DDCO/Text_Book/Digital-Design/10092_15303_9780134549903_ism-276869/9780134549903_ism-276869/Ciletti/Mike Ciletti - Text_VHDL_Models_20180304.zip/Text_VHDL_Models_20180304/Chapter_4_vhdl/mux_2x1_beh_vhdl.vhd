  -- VHDL behavioral description of two-channel multiplexer
  Library IEEE;
  use IEEE.Std_Logic_1164.all;
  
  
  entity mux_2x1_beh_vhdl is
  port (m_out: out Std_Logic; A, B: in Std_Logic; 
  sel: in Std_Logic);	-- select is a reserved word
  end mux_2x1_beh_vhdl;
  
  Architecture Behavioral of mux_2x1_beh_vhdl is
  begin
  	process (A, B, sel) begin
    	if sel = '1' then m_out <= A; else m_out <= B; end if;
   end process;
   end Behavioral;

