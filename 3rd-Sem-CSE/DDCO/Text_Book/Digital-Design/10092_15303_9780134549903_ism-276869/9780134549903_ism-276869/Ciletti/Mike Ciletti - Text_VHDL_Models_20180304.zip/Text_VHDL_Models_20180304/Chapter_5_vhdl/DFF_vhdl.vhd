Library IEEE;
use IEEE.Std_Logic_1164.all;-- D flip-flop with active-low, asynchronous reset
entity DFF_vhdl is
  port (Q: out Std_Logic; D, Clk, rst: in Std_Logic);
end DFF_vhdl;

architecture Behavioral of DFF_vhdl isbegin
  process (Clk, rst) begin
    if rst'event and rst = '0' then Q <= '0';
    elsif Clk'event and Clk = '1' then Q <= D;
	end if;
  end process;
end Behavioral;

