Library IEEE;
use IEEE.Std_Logic_1164.all;


entity half_adder_vhdl is    port (S, C: out Std_Logic; x, y: in Std_Logic);end half_adder_vhdl;architecture Dataflow of half_adder_vhdl is
begin    S <= x xor y;    C <= x and y;end Dataflow;
Library IEEE;
use IEEE.Std_Logic_1164.all;
entity full_adder_vhdl is    port (S, C: out Std_Logic; x, y, z: in Std_Logic);end full_adder_vhdl;architecture Structural of full_adder_vhdl is    signal S1, C1, C2: Std_Logic;    component half_adder_vhdl port (S, C: out Std_Logic; x, y: in Std_Logic); end component;begin    HA1: half_adder_vhdl port map (S => S1, C => C1, x => x, y => y);    HA2: half_adder_vhdl port map (S => S, C => C2, x => S1, y => z);    C <= C2 or C1;end Structural;
Library IEEE;
use IEEE.Std_Logic_1164.all;
entity ripple_carry_4_bit_adder_vhdl is     port (Sum: out Std_Logic_Vector (3 downto 0); C4: out Std_Logic; A, B: in              Std_Logic_Vector (3 downto 0); C0: in Std_Logic);end ripple_carry_4_bit_adder_vhdl;architecture Structural of ripple_carry_4_bit_adder_vhdl is signal C1, C2, C3: Std_Logic;component full_adder_vhdl port (S, C: out Std_Logic; x, y, z: in Std_Logic); end component;begin    FA0: full_adder_vhdl port map (S => Sum(0), C => C1, x => A(0), y => B(0), z => C0);    FA1: full_adder_vhdl port map (S => Sum(1), C => C2, x => A(1), y => B(1), z => C1);    FA2: full_adder_vhdl port map (S => Sum(2), C => C3, x => A(2), y => B(2), z => C2);    FA3: full_adder_vhdl port map (S => Sum(3), C => C4, x => A(3), y => B(3), z => C3);end Structural;