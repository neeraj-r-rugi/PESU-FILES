Library IEEE;
use IEEE.Std_Logic_1164.all;

entity JK_FF_vhdl is
    port (Q: buffer Std_Logic; Q_b: out Std_Logic; J, K: in bit_vector (0 downto 0); Clk, rst: in Std_Logic); 
end JK_FF_vhdl;

architecture Behavioral_Case_vhdl of JK_FF_vhdl is
begin
    Q_b <= not Q;
    process (Clk) begin
	 if CLK'event and CLK = '1' then
		if (rst = '1') then Q <= '0';
		else 
			case (J & K) is
           			when "00" => Q <= Q;
           			when "01" => Q <= '0';
           			when "10" => Q <= '1';
           			when "11" => Q <= not Q;
			  	when others => Q <= Q;
      		end case;
		end if; 
	 end if;
    end process;
end Behavioral_Case_vhdl;

