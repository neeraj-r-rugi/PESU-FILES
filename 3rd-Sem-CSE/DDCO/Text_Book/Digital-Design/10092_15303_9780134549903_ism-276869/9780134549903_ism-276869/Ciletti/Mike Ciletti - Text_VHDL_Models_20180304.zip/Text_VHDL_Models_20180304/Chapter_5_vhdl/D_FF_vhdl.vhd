-- D flip-flop without reset


Library IEEE;
use IEEE.Std_Logic_1164.all;

entity D_FF_vhdl is
  port (Q: out Std_Logic; D, Clk: in Std_Logic);
end D_FF_vhdl;

architecture Behavioral of D_FF_vhdl is
begin

process (Clk) begin
  if Clk'event and Clk = '1' then Q <= D; end if;
  end process;
end Behavioral;
