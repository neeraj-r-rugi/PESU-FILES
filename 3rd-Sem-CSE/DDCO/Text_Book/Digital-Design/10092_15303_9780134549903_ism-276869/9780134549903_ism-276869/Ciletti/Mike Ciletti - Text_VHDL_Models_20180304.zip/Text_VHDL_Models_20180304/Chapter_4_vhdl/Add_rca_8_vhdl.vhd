library ieee;
use ieee.std_logic_1164.all;

entity and2_gate is		 
   port (A, B: in Std_Logic; C: out Std_Logic);
end and2_gate;

architecture Boolean_Equation of and2_gate is
begin
   C <= A and B;	 
end Boolean_Equation;

library ieee;
use ieee.std_logic_1164.all;

entity or2_gate is		 
   port (A, B: in Std_Logic; C: out Std_Logic);
end or2_gate;

architecture Boolean_Equation of or2_gate is
begin
   C <=  A or B;	
end Boolean_Equation;


library ieee;
use ieee.std_logic_1164.all;

entity xor2_gate is		
   port (A, B: in Std_Logic; C: out Std_Logic);
end xor2_gate;

architecture Boolean_Equation of xor2_gate is
begin
   C <= A xor B;
end Boolean_Equation;

library ieee;
use ieee.std_logic_1164.all;

entity Add_half_vhdl is 
   port (a, b: in std_logic; c_out, sum: out std_logic);   
end Add_half_vhdl;

architecture Structure of Add_half_vhdl is	

	component and2_gate 
		port (A, B: in Std_Logic; C: out Std_Logic);
	end component;

	component xor2_gate 
		port (A, B: in Std_Logic; C: out Std_Logic);
	end component;

begin			
      G1: xor2_gate	port map (a, b, sum);
      G2: and2_gate	port map (a, b, c_out); 
end Structure;

library ieee;
use ieee.std_logic_1164.all;

entity Add_full_vhdl is
	port (a, b, c_in: in std_logic; c_out, sum: out std_logic);
end Add_full_vhdl;

architecture Structure of Add_full_vhdl is
	signal w1, w2, w3: std_logic;
	
	component or2_gate		 	
		port (a, b: in std_logic; c: out std_logic);
	end component;
	
	component Add_half_vhdl
		port (a, b: in std_logic; c_out, sum: out std_logic);
	end component;	

begin
	M0: Add_half_vhdl port map (w2, c_in, w3, sum); 
	M1: Add_half_vhdl port map (a, b, w1, w2);
	G1: or2_gate 		port map (w1, w3, c_out); 
end Structure;

library ieee;
use ieee.std_logic_1164.all;

entity Add_rca_4_vhdl is
	port (A, B: in Std_Logic_vector (3 downto 0); c_in: in Std_Logic; 
	c_out: out Std_Logic; sum: out Std_Logic_vector (3 downto 0));
end Add_rca_4_vhdl;

architecture Structure of Add_rca_4_vhdl is
	signal c_in1, c_in2, c_in3: Std_Logic;
	
	component Add_full_vhdl
		port (a, b, c_in: in Std_Logic; c_out, sum: out Std_Logic);
	end component;

begin
	M0: Add_full_vhdl port map (a(0), b(0), c_in,  c_in1, sum(0));
	M1: Add_full_vhdl port map (a(1), b(1), c_in1, c_in2, sum(1));
	M2: Add_full_vhdl port map (a(2), b(2), c_in2, c_in3, sum(2));
	M3: Add_full_vhdl port map (a(3), b(3), c_in3, c_out, sum(3));
end Structure;

library ieee;
use ieee.std_logic_1164.all;

entity Add_rca_8_vhdl is
	port (a, b: in Std_Logic_Vector (7 downto 0); c_in: in Std_Logic; 
       c_out: out Std_Logic; sum: out Std_Logic_Vector (7 downto 0));
end Add_rca_8_vhdl;

architecture Structure of Add_rca_8_vhdl is
	signal c_in4: Std_Logic;
	component Add_rca_4_vhdl	
		port (a, b: in Std_Logic_Vector (3 downto 0); c_in: in Std_Logic;
       c_out: out Std_Logic; sum: out Std_Logic_Vector (3 downto 0));
	end component;
begin			 
	M0: Add_rca_4_vhdl port map (a(3 downto 0), b(3 downto 0), c_in, c_in4, sum(3 downto 0 ));
	M1: Add_rca_4_vhdl port map (a(7 downto 4), b(7 downto 4), c_in4, c_out, sum(7 downto 4 ));
end Structure;
