  -- VHDL behavioral description of four-channel multiplexer
  entity mux_4x1_beh_vhdl is_
  port (m_out: out Std_Logic; in_0, in_1, in_2, in_3: in Std_Logic; 
  sel: in Std_Logic_Vector (1 downto 0));
  end mux_4x1_beh_vhdl;
  
  Architecture Behavioral of mux_4x1_beh_vhdl is
  begin
  process (in_0, in_1, in_2, in_3, sel) begin
  case sel is
  when 0 => m_out <= in_0;
  when 1 => m_out <= in_1;
  when 2 => m_out <= in_2;
when 3 => m_out <= in_3;
  when others => m_out <= 'in_0;
  endcase;
  end process;
  end Behavioral;


