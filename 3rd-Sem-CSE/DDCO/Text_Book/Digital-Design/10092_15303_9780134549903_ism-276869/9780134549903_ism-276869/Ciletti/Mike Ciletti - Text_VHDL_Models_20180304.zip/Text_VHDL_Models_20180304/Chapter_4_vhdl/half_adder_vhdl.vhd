Library IEEE;
use IEEE.Std_Logic_1164.all;


entity half_adder_vhdl is
    port (S, C: out Std_Logic; x, y: in Std_Logic);
end half_adder_vhdl;

architecture Dataflow of half_adder_vhdl is
begin
    S <= x xor y;
    C <= x and y;
end Dataflow;



