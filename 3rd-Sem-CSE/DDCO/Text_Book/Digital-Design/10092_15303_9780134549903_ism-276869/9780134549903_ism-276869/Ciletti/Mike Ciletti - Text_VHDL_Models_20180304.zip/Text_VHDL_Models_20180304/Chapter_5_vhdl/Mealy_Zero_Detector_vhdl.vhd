library ieee;
use ieee.std_logic_1164.all;

entity Mealy_Zero_Detector_vhdl is 
	port (y_out: out std_logic; x_in, clock, reset: in std_logic);
end Mealy_Zero_Detector_vhdl;



architecture Behavioral of Mealy_Zero_Detector_vhdl is   
	type state_type is (S0, S1, S2, S3);	-- machine states
	
signal state, next_state: state_type;

begin

	process (clock, reset) begin	-- Synchronous state transitions
      if reset = '0' then state <= S0; 
      elsif clock'event and clock = '1' then state <= next_state; end if;
   end process;	

    process (state, x_in) begin	-- Next state
      case (state) is
         when 	S0	=> 	if x_in  = '1' then 
									next_state <= S1; 
								else next_state <= S0; 
								end if;							
	
         when 	S1	=> 	if (x_in  = '1') then 
									next_state <= S3; 
								else next_state <= S0;
								end if;
								
        when 	S2	=> 	if x_in  = '0' then 
									next_state <= S0; 
								else next_state <= S2;
								end if;
								
	  		when 	S3	=> if (x_in  = '1') then 
									next_state <= S2; 
								else next_state <= S0;
								end if;																			
 				
			when others	=>	next_state <= S0;
      end case;
   end process;

    process (state, x_in) begin	-- Output
      case (state) is
         when 	S0	=> y_out <= '0';
         when 	S1	=>	y_out <= not x_in;
         when 	S2	=>	y_out <= not x_in;
         when 	S3	=>	y_out <= not x_in; 
			when others => y_out <= '0';
      end case;
   end process;
end Behavioral;

library ieee;
use ieee.std_logic_1164.all;

entity t_Mealy_Zero_Detector_vhdl is
end t_Mealy_Zero_Detector_vhdl; 

architecture Behavioral of t_Mealy_Zero_Detector_vhdl is
   signal t_y_out: std_logic;
   signal t_x_in, t_clock, t_reset: std_logic;
	component Mealy_Zero_Detector_vhdl is
		port (y_out: out std_logic; x_in, clock, reset: in std_logic);	
	end component;
		
	
begin
      -- Instantiate the UUT
  UUT: Mealy_Zero_Detector_vhdl port map (y_out => t_y_out, x_in => t_x_in, clock => t_clock, reset => t_reset);
  
  -- Create free-running clock signal;
   process (t_clock) begin
      t_clock <= not t_clock after 5 ns; 
   end process;

	-- Specify stimulus signal signals
   process begin
      t_reset 	<= '0';
      t_reset 	<= '1' after 2 ns;
      t_reset 	<= '0' after 87 ns;
      t_reset 	<= '1' after 89 ns;
      t_x_in	<= '1' after 10 ns;
      t_x_in	<= '0' after 30 ns;
      t_x_in	<= '1' after 40 ns;
      t_x_in	<= '0' after 50 ns;
      t_x_in	<= '1' after 52ns;
      t_x_in	<= '0' after 54 ns;
      t_x_in	<= '1' after 70 ns;
      t_x_in	<= '0' after 80 ns;
      t_x_in	<= '1' after 90 ns;
      t_x_in	<= '0' after 100 ns;
      t_x_in	<= '1' after 120 ns;
      t_x_in	<= '0' after 160 ns;
      t_x_in	<= '1' after 170 ns;
   end process;
end Behavioral;

