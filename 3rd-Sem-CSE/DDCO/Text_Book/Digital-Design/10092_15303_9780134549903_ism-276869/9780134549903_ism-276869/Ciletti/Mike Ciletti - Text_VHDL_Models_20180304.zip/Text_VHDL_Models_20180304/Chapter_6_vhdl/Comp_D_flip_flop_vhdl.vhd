Library IEEE;
use IEEE.Std_Logic_1164.all;

entity Comp_D_flip_flop_vhdl is
port (Q: buffer Std_Logic; CLK, Reset: in Std_Logic);
end Comp_D_flip_flop_vhdl;
					
architecture Behavioral of Comp_D_flip_flop_vhdl is
 begin
  process (CLK, Reset) begin
 if Reset'event and Reset = '1' then Q <= '0';
  elsif CLK'event and CLK = '0' then Q <= not Q after 2 ns;
  end if;
  end process;
end Behavioral;

Library IEEE;
use IEEE.Std_Logic_1164.all;

entity Ripple_Counter_4bit is
port (A3, A2, A1, A0: buffer Std_Logic; Count, Reset: in Std_Logic);
end Ripple_Counter_4bit;

architecture Structural of Ripple_Counter_4bit is
  component Comp_D_flip_flop_vhdl port (Q: out Std_Logic; CLK, Reset: in Std_Logic);
  end component;
begin
  F0: Comp_D_flip_flop_vhdl port map (Q => A0, CLK => Count, Reset => Reset);
  F1: Comp_D_flip_flop_vhdl port map (Q => A1, CLK => A0, Reset => Reset);
  F2: Comp_D_flip_flop_vhdl port map (Q => A2, CLK => A1, Reset => Reset);
  F3: Comp_D_flip_flop_vhdl port map (Q => A3, CLK => A2, Reset => Reset);
end Structural;
  
  -- stimulus for four-bit ripple counter

Library IEEE;
use IEEE.Std_Logic_1164.all;
  
entity t_Ripple_Counter_4bit is
--port ();
end  t_Ripple_Counter_4bit;

architecture Behavioral of t_Ripple_Counter_4bit is
signal t_A3, t_A2, t_A1, t_A0, t_Count, t_Reset: Std_Logic;
  component Ripple_Counter_4bit port (A3, A2, A1, A0: out Std_Logic; Count, Reset: in Std_Logic);
  end component;
-- Instantiate UUT
begin
UUT: Ripple_Counter_4bit port map (A3 => t_A3, A2 => t_A2, A1 => t_A1, A0 => t_A0, 
  Count => t_Count, Reset => t_Reset);
  
process 
begin
t_count <= '0';
t_count <= not t_count after 5 ns;
end process;

process  
begin
t_Reset <= '0';
wait for 4 ns;
t_Reset <= '1';
end process;
end Behavioral;
