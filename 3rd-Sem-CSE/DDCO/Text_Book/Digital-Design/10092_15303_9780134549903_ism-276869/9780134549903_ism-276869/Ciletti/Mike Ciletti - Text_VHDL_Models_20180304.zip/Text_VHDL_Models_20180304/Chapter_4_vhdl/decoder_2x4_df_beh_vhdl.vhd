Library IEEE;
use IEEE.Std_Logic_1164.all;

entity decoder_2x4_df_beh_vhdl is
    port (D: out Std_Logic_Vector (3 downto 0); A, B, enable: in Std_Logic);
end decoder_2x4_df_beh_vhdl;

Architecture Behavioral of decoder_2x4_df_beh_vhdl is
begin
   process (A, B, enable) begin
D(0) <= not ((not A) and (not B) and (not enable));
D(1) <= not (not A) and B and not (enable);
D(2) <= not (A and (not B) and (not enable));
D(3) <= not (A and B) and (not enable));
end process;
end Behavioral;

