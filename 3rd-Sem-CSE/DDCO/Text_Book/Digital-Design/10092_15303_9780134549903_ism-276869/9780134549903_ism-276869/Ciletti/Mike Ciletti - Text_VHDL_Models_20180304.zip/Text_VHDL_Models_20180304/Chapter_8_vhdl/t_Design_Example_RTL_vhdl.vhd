library ieee;
use ieee.std_logic_1164.all;

-- Test bench for Design_Example_RTL_vhdl in VHDL Example 8.2

entity t_Design_Example_RTL_vhdl is
end t_Design_Example_RTL_vhdl;

architecture Test_Bench of t_Design_Example_RTL_vhdl is 
 
   signal 	t_A: std_logic_vector (3 downto 0); 
   signal	t_E, t_F, t_Start, t_clock, t_reset_b: std_logic; 
	
   component Design_Example_RTL_vhdl port (A: out Std_logic_vector (3 downto 0); E, F: out Std_logic; Start, clock, reset_b: in Std_Logic); 
		
	end component;

begin

	M0: Design_Example_RTL_vhdl port map (A => t_A, E => t_E, F => t_F, Start=> t_Start, clock => t_clk, reset_b => t_reset_b);
			

-- Stimulus signals

	t_reset_b 	<= '0';
	t_Start 	<= '0';
	t_reset_b 	<= '1' after 5ns;
   	t_Start 	<= '1' after 5 ns;


process begin
	t_clock <= '0';
	for k in 0 to 32 loop
    		wait for 5 ns;
		t_clock <= not t_clock; 
	end loop;
	wait;
end process;
end Test_Bench;
