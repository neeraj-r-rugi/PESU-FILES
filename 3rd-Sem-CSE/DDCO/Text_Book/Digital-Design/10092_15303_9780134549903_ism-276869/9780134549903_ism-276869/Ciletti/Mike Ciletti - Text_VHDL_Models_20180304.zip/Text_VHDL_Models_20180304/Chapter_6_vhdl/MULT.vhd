Library IEEE;
use IEEE.Std_Logic_1164.all;
use IEEE.Std_Logic_unsigned.all;
use IEEE.Std_Logic_arith.all;


entity MULT is
	generic (dp_width: integer := 5);
   port (Multiplicand, Multiplier: in Unsigned (dp_width-1 downto 0);
    		Product: out Unsigned (2*dp_width downto 0));
end MULT;

-- Behavioral (RTL) description of a parallel multiplier (word size = 5 bits)

architecture RTL of MULT is
	signal A, B, Q: Unsigned (dp_width-1 downto 0);	-- Sized for datapath width

begin

	
process (Multiplier, Multiplicand) 

variable v_C: Unsigned (0 downto 0);
variable v_A, v_B, v_Q: Unsigned (dp_width-1 downto 0);
variable sum: Unsigned (dp_width downto 0);
begin
	for k in 2*dp_width downto 0 loop Product(k) <= '0'; end loop;
	v_Q := Multiplier;
	v_B := Multiplicand;	
	v_C := "0";

	for k in dp_width-1 downto 0 loop v_A(k) := '0'; end loop;
	
	for k in 0 to 31 loop
	  if v_Q(0) = '1' then

			--v_A := sum (dp_width-1 downto 0);
			--v_C := sum (dp_width);
			
			
       --C & A & Q <= (C & Q & A) srl 1;
		--	Product <= Product srl 1;
			v_Q := '0' & v_Q(dp_width-1 downto 1);
			v_A := v_C & v_A(dp_width-1 downto 1);
			v_C := ("0");
		Product <= v_C & v_A & v_Q;
		sum := ('0' & v_A) + ('0' & v_B);		-- Sig assign?????
			
	  end if;
	end loop;	
end process;
end architecture;

Library IEEE;
use IEEE.Std_Logic_1164.all;
use IEEE.Std_Logic_arith.all;
use IEEE.Std_Logic_unsigned.all;


entity t_MULT is
	generic (dp_width: integer := 5);
end t_MULT;

architecture Test_Bench of t_MULT is
 	signal	t_Multiplicand, t_Multiplier: Unsigned (dp_width -1 downto 0);
	signal	t_product: Unsigned (2*dp_width -1 downto 0);
	signal	Exp_value: unsigned (2*dp_width -1 downto 0);
	signal 	Error: bit;	

	component MULT port (Multiplicand, Multiplier: Unsigned (dp_width-1 downto 0); Product: Unsigned (2*dp_width-1 downto 0));
	end component;
	begin
	
-- Instantiate UUT

M0: MULT port map (Multiplicand => t_Multiplicand, Multiplier => t_Multiplier,  Product => t_Product);

-- Error Detection

process (t_Product) begin
	Exp_Value <= t_Multiplier * t_Multiplicand;
    -- Exp_Value <= Multiplier * Multiplicand +1;	-- Inject error to confirm detection
	if Exp_Value = t_Product then Error <= '0'; else Error <= '1'; end if;
end process;


 -- Generate multiplier and multiplicand exhaustively for 5-bit operands
process begin
    t_Multiplicand <= "0" after 5 ns;
    t_Multiplicand <= "0";
	for k_outer in 0 to 31 loop
		t_Multiplier <= t_Multiplier + 1;
   for k_inner in 0 to 31 loop
		t_Multiplicand <= t_Multiplicand + 1;
	  end loop;
	end loop;	
end process;

end architecture;
