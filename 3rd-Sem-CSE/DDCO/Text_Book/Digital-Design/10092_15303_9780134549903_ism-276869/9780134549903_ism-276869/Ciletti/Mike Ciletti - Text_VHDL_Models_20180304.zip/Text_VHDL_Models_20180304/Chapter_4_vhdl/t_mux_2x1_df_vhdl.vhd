-- Test bench with stimulus for mux_2x1_df_vhdl

Library IEEE;
use IEEE.Std_Logic_1164.all;

-- Note: select is a reserved word

entity t_mux_2x1_df_vhdl is
end t_mux_2x1_df_vhdl;

architecture Dataflow of t_mux_2x1_df_vhdl is
	signal t_A, t_B, t_C: Std_Logic;
	signal t_sel: Std_Logic;
	signal t_mux_out: Std_Logic;
	component mux_2x1_df_vhdl 
		port (A, B: in Std_Logic; C: out Std_Logic; sel: in Std_Logic);
		end component;
begin
process begin
-- Stimulus signal assignments
	t_sel <= '1'; t_A <= '0'; t_B <= '1'; t_C <= '0';
	wait for 10 ns;
	t_A <= '1';
	t_B <= '0'; t_C <= '1';
	wait for 10 ns;
	t_sel <= '0'; 
	wait for 10 ns;
	t_A <= '0'; t_B <= '1'; t_C <= '1';
end process;
-- Instantiate UUT
	M0: mux_2x1_df_vhdl port map (a => t_A, B => t_B, C => t_C,
sel => t_sel);
end Dataflow;

