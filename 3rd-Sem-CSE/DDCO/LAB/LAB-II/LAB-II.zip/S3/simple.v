/*
 T(Temperature) = 1
 P(Present) = 1

 --> Run Fan
*/
module   or2(c, a, b);
    input a;
    input b;
    output c;
    assign c = a | b;
    
endmodule
module  and2(c, a, b);
    input a;
    input b;
    output c;
    assign c = a&b;
    
endmodule

module fan(A, B, C, D);
input A,B,C;
output D;
wire and_out;
and2 G1(and_out, A, B);
or2 G2(D, C, and_out);

endmodule